Resources for preparing the package for CRAN submission

- goodpractice package: <https://github.com/mangothecat/goodpractice> (DONE)
- checking package on Windows with different R versions: <https://win-builder.r-project.org/> (DONE)
- checking package on Macs (In process)
- Wickham/Bryan book on packages: <https://r-pkgs.org/> (DONE)
- CRAN package policies: <https://cran.r-project.org/web/packages/policies.html> (?)
- A short intro to the submission process: <https://kbroman.org/pkg_primer/pages/cran.html> (In process)


 - Multiple platforms automated cghcker:
 <https://github.com/r-hub/rhub> 


- Checklist for CRAN submissions
<https://cran.r-project.org/web/packages/submission_checklist.html>

